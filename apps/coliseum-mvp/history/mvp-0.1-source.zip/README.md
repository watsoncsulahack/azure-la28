# Coliseum 3D MVP

Three.js 0.170.0, vendored locally. A reference-based, navigable first model of the Los Angeles Memorial Coliseum. No photo intake or image reconstruction is included.

## Run and rebuild

Serve `dist/` through any ordinary static HTTP server. For example, on your own machine, run `python -m http.server 3000 --directory dist` and open `http://localhost:3000`. ES modules need HTTP; opening the HTML directly from disk is unsupported.

No dependency installation or bundling is required. Node 20+ can validate and regenerate the binary model:

```sh
node scripts/check-model.mjs
node scripts/export-model.mjs
node scripts/check-export.mjs
node scripts/package.mjs
```

Edit `dist/data/venue.json` to change dimensions or model assumptions, then rerun both commands. Reload the viewer: it uses those same inputs and the same `dist/model.js` generator. Synchronize `manifest.json` after metadata or evidence changes. Generated assets and reports carry revision `0.1.0`; increment the revision for subsequent releases. `scripts/package.mjs` rebuilds the distributable source ZIP and evidence manifest.

## Architecture

- `dist/data/venue.json`: metric dimensions, coordinate convention, component definitions, evidence links and explicit estimates.
- `dist/model.js`: procedural geometry, stable component IDs, walking surfaces, simple architectural collision boxes, and source-consistency checks.
- `dist/app.js`: first-person and third-person walking, overview orbit/pan/zoom, scene layers, location jumps, labels and GLB download.
- `dist/navigation.js`: shared, tested walking-surface and architectural-obstacle constraints.
- `dist/data/manifest.json`: engineering evidence and omissions; not a visitor-facing measurement tool.
- `dist/data/validation.json`: actual generated geometry checks and verification limits.
- `dist/coliseum-0.1.0.glb`: reproducible export with component metadata and `EXT_mesh_gpu_instancing` seating. Consumers need that standard extension to show seating instances.
- `dist/data/*.csv`: copies of the research catalog used for this release.

Stable top-level IDs: `field`, `bowl`, `seats`, `circulation`, `tower`, `peristyle`, `context`, `displays`. Seven tower levels retain separate semantic IDs. Seat instance count is a rendering choice, not a capacity estimate.

## Evidence and accuracy

Sources: https://github.com/watsoncsulahack/azure-la28/tree/main/research/coliseum-dimensions

S01 (Draft Technical Guide 2024) supplies field/street/last-row height relationships, tower and cauldron overall height references, field/football dimensions, arch count and display size. S04 supplies a provisional historic approximate outer ellipse. The S01 p.5 site plan was visually inspected for layout, but has not been metrically registered or traced in this MVP.

The field reference is local Y=0; X points schematically east, Z schematically south and Y up. This is a right-handed coordinate system, not a geographic survey. The field is an estimated elliptical interpolation of reported extents; widths at unknown stations are not invented as measured controls. Bowl profiles, inner outline, row count/spacing, tower footprint and floor elevations, peristyle details, surrounding landscape and circulation are estimates. Historic geometry and current operating references are explicitly combined as a provisional modeling assumption. No undatumed design elevation is treated as a field-relative as-built elevation.

Target physical tolerance is 0.30 m. Current checks establish that chosen published dimensions are represented consistently in generated meshes; they do not independently establish physical accuracy within 0.30 m. No independent site checks have been performed. See assumptions A001–A008 and the coverage/omissions in the manifest.

## Navigation limits

Overview, first-person and third-person are implemented. WASD moves; drag looks; Shift moves faster. Location buttons move to the field, north bowl, peristyle terrace and south sideline. Third-person includes a visitor avatar. Walking follows raycast model surfaces, limits step height and blocks modeled tower walls and peristyle piers. Seats are decorative, and the pedestrian network and interiors are incomplete. The app does not assert real-world accessible routes or reproduce every barrier. Third-person camera collision is simplified. Runtime browser/device validation has not been performed because the managed browser tool was unavailable during this build.

## Revision 0.1.0

Initial dimension-anchored geometry, navigation viewer, evidence manifest, numeric checks and GLB asset. Temporary LA28 installations, detailed interiors, actual seat inventories, photo corrections and general multi-venue generation remain future work. Parameters are separated from rendering to support those later stages, but this generator currently implements Coliseum-specific component construction.

Three.js and its examples are MIT licensed; see `dist/vendor/LICENSE`. Research source documents retain their publishers' rights. This is an independent prototype, not an official LA28 or Coliseum publication.
